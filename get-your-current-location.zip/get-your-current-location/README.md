# Get your current location

A Pen created on CodePen.io. Original URL: [https://codepen.io/cssmonkey/pen/MwpZyQ](https://codepen.io/cssmonkey/pen/MwpZyQ).

Uses OpenStreetMap geocoding and GeoLocation api to return your location